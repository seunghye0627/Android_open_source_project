package com.example.administrator.assignment;


/* **********************************************
 * 프로그램명 : assignment
 * 작성자 : 2018038019 최승혜
 * 작성일 : 2020.04.12
 * 프로그램 설명 : Hello Android 프로그램.
 * 첫번재 버튼 터치 시 네이버 주소가 토스트 메세지로 뜸
 * 두번째 버튼 터치 시 해당 링크로 연결
 * 라디오 버튼 터치 시 각 버튼 마다 다른 고양이 사진을 띄움

 ************************************************/


import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;
import android.net.Uri;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    EditText Et1;
    Button Bt1, Bt2;
    RadioGroup rg;
    RadioButton Ra1, Ra2;
    ImageView Img1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Et1 = (EditText) findViewById(R.id.editText1);
        Bt1 = (Button) findViewById(R.id.button1);
        Bt2 = (Button) findViewById(R.id.button2);
        Ra1 = (RadioButton) findViewById(R.id.RadioButton1);
        Ra2 = (RadioButton) findViewById(R.id.RadioButton2);
        Img1 = (ImageView) findViewById(R.id.imgCat);
    View.OnClickListener listener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            switch(view.getId())
            {
                case R.id.button1:
                    String msg = Et1.getText().toString();
                    Toast.makeText(getApplicationContext(), msg,Toast.LENGTH_LONG).show();
                    break;
                case R.id.button2:
                    String link = Et1.getText().toString();
                    Intent newIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(link));
                    startActivity(newIntent);
                    break;
                case R.id.RadioButton1:
                    Img1.setImageResource(R.drawable.cat1);
                    break;
                case R.id.RadioButton2:
                    Img1.setImageResource(R.drawable.cat2);
                    break;

            }

        }
    };

    Bt1.setOnClickListener(listener);
    Bt2.setOnClickListener(listener);
    Ra1.setOnClickListener(listener);
    Ra2.setOnClickListener(listener);

    }


}
